'use strict';
var ViewModel,
    Observable = require('data/observable').Observable;
// additional requires

ViewModel = new Observable({

    pageTitle: 'HomeView',
    // additional properties
});
module.exports = ViewModel;