DockBooking-NS-drawer-boilerplate
===

A simple template for starting over with an empty app.
Features:

- Typescript
- Nativescript UI pro node module with drawer navigation
- some fonts in `fonts`
- icons and launchscreen in `App_Resources`

Setup
----

```
npm install
```


Run
----

```
tns run [ios|android]
```
