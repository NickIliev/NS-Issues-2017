'use strict';
var isInit = true,
    helpers = require('../../utils/widgets/helper'),
    navigationProperty = require('../../utils/widgets/navigation-property'),
    // additional requires
    viewModel = require('./homeView-view-model');

// additional functions
var Card = require('nativescript-stripe');
var Stripe = require('nativescript-stripe').Stripe;
const stripe = new Stripe('pk_test_3kSd0ztS0q1OaOC9IaZnIhx2');

function pageLoaded(args) {
    var page = args.object;

    helpers.platformInit(page);
    page.bindingContext = viewModel;
    // additional pageLoaded

    if (isInit) {
        isInit = false
        // additional pageInit
    }


    
    const cc = new Card("1111111111111111", 2, 18, "123");
    cc.name = "Osei Fortune";


    stripe.createToken(cc.card, (error, token) => {
        if (!error) {
            //Do something with your token; 

        } else {
            console.log(error);
        }
    });


}

// START_CUSTOM_CODE_homeView
// Add custom code here. For more information about custom code, see http://docs.telerik.com/platform/screenbuilder/troubleshooting/how-to-keep-custom-code-changes

// END_CUSTOM_CODE_homeView
exports.pageLoaded = pageLoaded;